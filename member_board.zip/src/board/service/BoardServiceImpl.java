package board.service;

import java.util.List;

import board.dao.BoardDao;
import board.vo.Board;

public class BoardServiceImpl implements BoardService{
	private BoardDao boardDao = new BoardDao();
	@Override
	public void write(Board board) {
		boardDao.write(board);
	}

	@Override
	public List<Board> list(Integer category) {
		return boardDao.list(category);
	}

	@Override
	public Board findBy(Integer boardno) {
		return boardDao.findBy(boardno);
	}

	@Override
	public void modify(Board board) {
		boardDao.modify(board);
	}

	@Override
	public void remove(Integer boardno) {
		boardDao.remove(boardno);
	}
	
}
