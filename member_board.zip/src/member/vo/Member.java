package member.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldNameConstants;

//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
//@ToString

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Member {
	private String userid;
	private String password;
	private String name;
	private String email;
	private String birthDate;
	private String regDate;
}
